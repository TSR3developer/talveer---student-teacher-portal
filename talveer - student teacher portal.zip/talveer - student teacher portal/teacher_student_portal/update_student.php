<?php
include 'db.php';

$id = $_POST['id'];
$name = $_POST['name'];
$subject = $_POST['subject'];
$marks = $_POST['marks'];

$updateQuery = "UPDATE students SET name = '$name', subject = '$subject', marks = $marks WHERE id = $id";
if ($conn->query($updateQuery)) {
    echo "updated";
} else {
    echo "failed";
}
?>
