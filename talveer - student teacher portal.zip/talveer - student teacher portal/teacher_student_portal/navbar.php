<style>
    body {
        margin: 0px !important;
    }
</style>
<?php
// Check if a session is already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

include 'db.php';

if (!isset($_SESSION['teacher'])) {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <div class="navbar">
        <div class="nav-left">
            <h3 class="nav_logo">Tailwebs</h3>
        </div>
        <div class="nav-right">
            <a href="home.php">Home</a>
            <a href="logout.php">Logout</a>
            <span class="ueser_type"><?php echo ucfirst($_SESSION['user_type']); ?></span>
        </div>
    </div>
</body>

</html>