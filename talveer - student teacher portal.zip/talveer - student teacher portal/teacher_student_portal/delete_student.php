<?php
include 'db.php';

$id = $_POST['id'];

$deleteQuery = "DELETE FROM students WHERE id = $id";
if ($conn->query($deleteQuery)) {
    echo "deleted";
} else {
    echo "failed";
}
?>
