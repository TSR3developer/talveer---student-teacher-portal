<?php include 'navbar.php'; ?>

<?php
$query = "SELECT * FROM students";
$result = $conn->query($query);

if ($_SESSION['user_type'] == 'admin') { ?>
    <style>
        #addStudentBtn {
            display: none;
        }
    </style>
<?php
}
if ($_SESSION['user_type'] == 'teacher') { ?>
    <style>
        .reg_techer {
            display: none;
        }
    </style>
<?php
}
?>
<div class="container">
    <h2>Welcome, <?php echo $_SESSION['teacher']; ?></h2>
    <button id="addStudentBtn">Add New Student</button>
    <div class="reg_techer">
        <a href="register.php" class="register-link">Register Teacher</a>
    </div>
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Subject</th>
                <th>Marks</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr data-id="<?php echo $row['id']; ?>">
                    <td contenteditable="true"><?php echo $row['name']; ?></td>
                    <td contenteditable="true"><?php echo $row['subject']; ?></td>
                    <td contenteditable="true"><?php echo $row['marks']; ?></td>
                    <td>
                        <button class="editBtn">Save</button>
                        <button class="deleteBtn">Delete</button>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- Add Student Modal -->
<div id="studentModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <form id="studentForm">
            <h2>Add New Student</h2>
            <div>
                <input type="text" id="studentName" placeholder="Student Name" required>
            </div>
            <div>
                <input type="text" id="subjectName" placeholder="Subject Name" required>
            </div>
            <div>
                <input type="number" id="studentMarks" placeholder="Marks" required>
            </div>
            <div>
                <button class="add_stu" type="submit">Add Student</button>
            </div>
        </form>
    </div>
</div>

<!-- <script src="script.js"></script> -->
<script>

document.addEventListener('DOMContentLoaded', function () {
    // Add student modal handling
    const modal = document.getElementById('studentModal');
    const addStudentBtn = document.getElementById('addStudentBtn');
    const closeModal = document.querySelector('.close');

    addStudentBtn.onclick = function () {
        modal.style.display = 'block';
    }

    closeModal.onclick = function () {
        modal.style.display = 'none';
    }

    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    }

    // Form submission for adding new student
    const studentForm = document.getElementById('studentForm');
    studentForm.onsubmit = function (e) {
        e.preventDefault();

        const name = document.getElementById('studentName').value;
        const subject = document.getElementById('subjectName').value;
        const marks = document.getElementById('studentMarks').value;

        const formData = new FormData();
        formData.append('name', name);
        formData.append('subject', subject);
        formData.append('marks', marks);

        fetch('add_student.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            if (data === 'inserted' || data === 'updated') {
                window.location.reload();
            } else {
                alert('Failed to add student');
            }
        });
    };

    // Handle edit and delete actions
    const editButtons = document.querySelectorAll('.editBtn');
    const deleteButtons = document.querySelectorAll('.deleteBtn');

    editButtons.forEach(button => {
        button.onclick = function () {
            const row = this.closest('tr');
            const id = row.getAttribute('data-id');
            const name = row.children[0].textContent;
            const subject = row.children[1].textContent;
            const marks = row.children[2].textContent;

            const formData = new FormData();
            formData.append('id', id);
            formData.append('name', name);
            formData.append('subject', subject);
            formData.append('marks', marks);

            fetch('update_student.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                if (data === 'updated') {
                    alert('Student updated successfully');
                } else {
                    alert('Failed to update student');
                }
            });
        };
    });

    deleteButtons.forEach(button => {
        button.onclick = function () {
            const row = this.closest('tr');
            const id = row.getAttribute('data-id');

            const formData = new FormData();
            formData.append('id', id);

            fetch('delete_student.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                if (data === 'deleted') {
                    window.location.reload();
                } else {
                    alert('Failed to delete student');
                }
            });
        };
    });
});


</script>