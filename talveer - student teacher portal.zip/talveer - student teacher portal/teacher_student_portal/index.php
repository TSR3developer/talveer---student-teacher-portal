<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM teachers WHERE username = '$username'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['teacher'] = $username;
            $_SESSION['user_type'] = $row['user_type'];  // Store user type in session
            header("Location: home.php");
        } else {
            $error = "Invalid username or password.";
        }
    } else {
        $error = "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Teacher Portal - Login</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <div class="login-container">
        <div class="login_title">
            <div>tailwebs.</div>
        </div>
        <div class="login_form">
            <form method="POST" action="">
                <h3>Login</h3>
                <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
                <div>
                    <input class="login_input" type="text" name="username" placeholder="Username" required>
                </div>
                <div>
                    <input class="login_input" type="password" name="password" placeholder="Password" required>
                </div>
                <div>
                    <button class="login_btn" type="submit">Login</button>
                </div>
            </form>

            <p>Don't have an account? <a href="register.php">Register here</a></p>
        </div>
    </div>

</body>

</html>