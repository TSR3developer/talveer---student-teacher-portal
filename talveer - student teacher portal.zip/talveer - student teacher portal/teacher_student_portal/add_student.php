<?php
include 'db.php';

$name = $_POST['name'];
$subject = $_POST['subject'];
$marks = $_POST['marks'];

$query = "SELECT * FROM students WHERE name = '$name' AND subject = '$subject'";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // $newMarks = $row['marks'] + $marks;
    $newMarks = $marks;
    $updateQuery = "UPDATE students SET marks = $newMarks WHERE id = " . $row['id'];
    $conn->query($updateQuery);
    echo "updated";
} else {
    $insertQuery = "INSERT INTO students (name, subject, marks) VALUES ('$name', '$subject', $marks)";
    $conn->query($insertQuery);
    echo "inserted";
}
?>
