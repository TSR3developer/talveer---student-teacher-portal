<?php
// Check if a session is already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include 'db.php';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        $checkQuery = "SELECT * FROM teachers WHERE username = '$username'";
        $result = $conn->query($checkQuery);

        if ($result->num_rows > 0) {
            $error = "Username already exists.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            $insertQuery = "INSERT INTO teachers (username, password) VALUES ('$username', '$hashed_password')";

            if ($conn->query($insertQuery)) {
                header("Location: index.php");
                exit;
            } else {
                $error = "Failed to register. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Teacher Portal - Register</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <?php if (isset($_SESSION['teacher'])) {
        include 'navbar.php';
    } ?> <!-- Conditionally include navbar -->

    <div class="login-container">

        <div class="register_title">
            <div>tailwebs.</div>
        </div>
        <div class="register_form">
            <form method="POST" action="">
                <h3>Register</h3>
                <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
                <div>
                    <input class="register_input" type="text" name="username" placeholder="Username" required>
                </div>
                <div>
                    <input class="register_input" type="password" name="password" placeholder="Password" required>
                </div>
                <div>
                    <input class="register_input" type="password" name="confirm_password" placeholder="Confirm Password" required>
                </div>
                <div>
                    <button class="register_btn" type="submit">Register</button>
                </div>
                <div class="bkbtn_main">
                    <a href="home.php" class="backbtn_link" > <div class="back_btn"> &larr; Back</div> </a>
                </div>
            </form>
            <!-- < ?php
            if (session_status() == PHP_SESSION_NONE) {
            ?> -->
                <p>Already have an account? <a href="index.php">Login here</a></p>
            <!-- < ?php
            }
            ?> -->
        </div>
    </div>
</body>

</html>